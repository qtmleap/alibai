#!/usr/bin/env python3
"""Test the packaging/applicator only, not the TypeScript application or Zod schemas."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

PACKAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('alibai_refactor_apply', PACKAGE / 'apply.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)


class ApplicatorTests(unittest.TestCase):
    def test_exact_replacement(self):
        self.assertEqual(module.transform('alpha beta', [
            {'kind': 'replace', 'old': 'alpha', 'new': 'gamma', 'count': 1},
        ], 'file'), 'gamma beta')

    def test_ambiguous_replacement_is_rejected(self):
        with self.assertRaises(module.ChangeError):
            module.transform('alpha alpha', [
                {'kind': 'replace', 'old': 'alpha', 'new': 'gamma', 'count': 1},
            ], 'file')

    def test_bounded_section_preserves_end_anchor(self):
        self.assertEqual(module.transform('before\nSTART\nold\nEND\nafter', [
            {'kind': 'section', 'start': 'START\n', 'end': 'END\n', 'new': 'START\nnew\n'},
        ], 'file'), 'before\nSTART\nnew\nEND\nafter')

    def test_paths_cannot_escape_repository(self):
        with tempfile.TemporaryDirectory(prefix='alibai-check-') as tmp:
            with self.assertRaises(module.ChangeError):
                module.safe_path(Path(tmp), '../outside')
            with self.assertRaises(module.ChangeError):
                module.safe_path(Path(tmp), '/outside')

    def fixture(self, tmp):
        root = Path(tmp)
        repo, package = root / 'alibai', root / 'package'
        (repo / 'db').mkdir(parents=True)
        (package / 'files/db').mkdir(parents=True)
        (repo / 'db/old.ts').write_bytes(b'const before = 1\n')
        (package / 'files/db/new.ts').write_bytes(b'const added = 2\n')
        manifest = {
            'format_version': 1,
            'modified': [{
                'path': 'db/old.ts',
                'expected_blob_sha': module.blob_sha(b'const before = 1\n'),
                'edits': [{'kind': 'replace', 'old': 'before', 'new': 'after', 'count': 1}],
            }],
            'created': ['db/new.ts'],
        }
        (package / 'changes.json').write_text(json.dumps(manifest))
        return repo, package

    def test_stale_source_aborts_before_writes(self):
        with tempfile.TemporaryDirectory(prefix='alibai-check-') as tmp:
            repo, package = self.fixture(tmp)
            (repo / 'db/old.ts').write_bytes(b'user edit\n')
            with self.assertRaises(module.ChangeError):
                module.plan_changes(repo, package)
            self.assertEqual((repo / 'db/old.ts').read_bytes(), b'user edit\n')
            self.assertFalse((repo / 'db/new.ts').exists())

    def test_existing_new_file_aborts_before_writes(self):
        with tempfile.TemporaryDirectory(prefix='alibai-check-') as tmp:
            repo, package = self.fixture(tmp)
            (repo / 'db/new.ts').write_bytes(b'user file\n')
            with self.assertRaises(module.ChangeError):
                module.plan_changes(repo, package)
            self.assertEqual((repo / 'db/old.ts').read_bytes(), b'const before = 1\n')
            self.assertEqual((repo / 'db/new.ts').read_bytes(), b'user file\n')

    def test_apply_changes_only_planned_files(self):
        with tempfile.TemporaryDirectory(prefix='alibai-check-') as tmp:
            repo, package = self.fixture(tmp)
            (repo / 'unrelated.txt').write_bytes(b'unchanged\n')
            changes = module.plan_changes(repo, package)
            module.apply_changes(changes)
            self.assertEqual((repo / 'db/old.ts').read_bytes(), b'const after = 1\n')
            self.assertEqual((repo / 'db/new.ts').read_bytes(), b'const added = 2\n')
            self.assertEqual((repo / 'unrelated.txt').read_bytes(), b'unchanged\n')
            self.assertFalse(list(repo.rglob('.scenario-refactor-*')))

    def test_exported_patch_passes_git_apply_check(self):
        with tempfile.TemporaryDirectory(prefix='alibai-check-') as tmp:
            repo = Path(tmp)
            (repo / 'db').mkdir()
            target = repo / 'db/old.ts'
            target.write_bytes(b'alpha\nbeta')
            changes = [
                module.Change('db/old.ts', target, b'alpha\nbeta', b'alpha\ngamma\n'),
                module.Change('db/new.ts', repo / 'db/new.ts', None, b'delta\n'),
            ]
            result = subprocess.run(['git', 'apply', '--check', '-'],
                cwd=repo, input=module.patch_for(changes), text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
