#!/usr/bin/env python3
"""Apply this package to an unchanged alibai checkout; dry-run unless --apply is set."""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import os
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class ChangeError(Exception):
    """A precondition failed; no repository file should be changed."""


@dataclass(frozen=True)
class Change:
    relative: str
    target: Path
    before: bytes | None
    after: bytes


def blob_sha(content: bytes) -> str:
    header = f"blob {len(content)}\0".encode("ascii")
    return hashlib.sha1(header + content).hexdigest()


def safe_path(root: Path, relative: str) -> Path:
    part = Path(relative)
    if part.is_absolute() or ".." in part.parts:
        raise ChangeError(f"Unsafe relative path: {relative}")
    path = root / part
    if path.is_symlink():
        raise ChangeError(f"Refusing symlink: {path}")
    if not path.resolve().is_relative_to(root.resolve()):
        raise ChangeError(f"Path escapes the repository: {relative}")
    return path


def transform(text: str, edits: list[dict[str, Any]], relative: str) -> str:
    for index, edit in enumerate(edits, 1):
        if edit["kind"] == "replace":
            old, new, expected = edit["old"], edit["new"], edit["count"]
            if not old or text.count(old) != expected:
                found = text.count(old) if old else "empty pattern"
                raise ChangeError(
                    f"{relative}: edit {index} expected {expected} matches, found {found}"
                )
            text = text.replace(old, new)
        elif edit["kind"] == "section":
            start, end = edit["start"], edit["end"]
            if not start or not end or text.count(start) != 1 or text.count(end) != 1:
                raise ChangeError(f"{relative}: edit {index} has ambiguous section anchors")
            left, right = text.index(start), text.index(end)
            if right <= left:
                raise ChangeError(f"{relative}: edit {index} has reversed section anchors")
            text = text[:left] + edit["new"] + text[right:]
        else:
            raise ChangeError(f"Unknown edit kind: {edit['kind']}")
    return text


def plan_changes(repo: Path, package: Path) -> list[Change]:
    manifest = json.loads((package / "changes.json").read_text(encoding="utf-8"))
    if manifest.get("format_version") != 1:
        raise ChangeError("Unsupported package version")
    changes: list[Change] = []
    seen: set[str] = set()
    for entry in manifest["modified"]:
        relative = entry["path"]
        if relative in seen:
            raise ChangeError(f"Duplicate target: {relative}")
        seen.add(relative)
        target = safe_path(repo, relative)
        before = target.read_bytes()
        actual = blob_sha(before)
        if actual != entry["expected_blob_sha"]:
            raise ChangeError(
                f"{target}: source differs from the reviewed file.\n"
                f"  expected Git blob: {entry['expected_blob_sha']}\n"
                f"  actual Git blob:   {actual}\n"
                "No files were changed. Reconcile local changes before applying this package."
            )
        after = transform(before.decode("utf-8"), entry["edits"], relative).encode("utf-8")
        changes.append(Change(relative, target, before, after))
    for relative in manifest["created"]:
        if relative in seen:
            raise ChangeError(f"Duplicate target: {relative}")
        seen.add(relative)
        target = safe_path(repo, relative)
        if target.exists():
            raise ChangeError(f"Refusing to overwrite new-file target: {target}")
        source = safe_path(package / "files", relative)
        changes.append(Change(relative, target, None, source.read_bytes()))
    return changes


def patch_for(changes: list[Change]) -> str:
    blocks: list[str] = []
    for change in changes:
        blocks.append(f"diff --git a/{change.relative} b/{change.relative}\n")
        if change.before is None:
            blocks.append("new file mode 100644\n")
        before = [] if change.before is None else change.before.decode("utf-8").splitlines(True)
        after = change.after.decode("utf-8").splitlines(True)
        for line in difflib.unified_diff(
            before,
            after,
            fromfile="/dev/null" if change.before is None else f"a/{change.relative}",
            tofile=f"b/{change.relative}",
        ):
            if line.endswith("\n"):
                blocks.append(line)
            else:
                blocks.append(line + "\n\\ No newline at end of file\n")
    return "".join(blocks)


def apply_changes(changes: list[Change]) -> None:
    # Check all files again before writing. Do not silently overwrite edits made during preflight.
    for change in changes:
        if change.before is None:
            if change.target.exists():
                raise ChangeError(f"Target appeared after preflight: {change.target}")
        elif change.target.read_bytes() != change.before:
            raise ChangeError(f"Target changed after preflight: {change.target}")
    staged: list[tuple[Path, Path]] = []
    try:
        # Stage every replacement before replacing any source file.
        for change in changes:
            change.target.parent.mkdir(parents=True, exist_ok=True)
            fd, name = tempfile.mkstemp(prefix=".scenario-refactor-", dir=change.target.parent)
            temporary = Path(name)
            staged.append((temporary, change.target))
            with os.fdopen(fd, "wb") as stream:
                stream.write(change.after)
            mode = 0o644 if change.before is None else change.target.stat().st_mode & 0o777
            temporary.chmod(mode)
        for temporary, target in staged:
            os.replace(temporary, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True, help="Path to the alibai checkout")
    action = parser.add_mutually_exclusive_group()
    action.add_argument("--apply", action="store_true", help="Write the seven planned source/test files")
    action.add_argument("--patch", type=Path, help="Write a unified diff instead of changing the repository")
    args = parser.parse_args()
    try:
        repo = args.repo.resolve(strict=True)
        package = Path(__file__).resolve().parent
        changes = plan_changes(repo, package)
        for change in changes:
            state = "ADD" if change.before is None else "MODIFY"
            print(f"{state:6} {repo.name}/{change.relative}")
        if args.patch is not None:
            if args.patch.exists():
                raise ChangeError(f"Refusing to overwrite patch file: {args.patch}")
            args.patch.write_text(patch_for(changes), encoding="utf-8")
            print(f"Wrote {args.patch}; repository files unchanged.")
        elif args.apply:
            apply_changes(changes)
            print("Applied seven source/test changes. No Git commit, DB update, or deployment was performed.")
        else:
            print("Preflight passed. Dry run only; add --apply to write or --patch FILE to export a diff.")
        return 0
    except (ChangeError, OSError, UnicodeError, ValueError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
