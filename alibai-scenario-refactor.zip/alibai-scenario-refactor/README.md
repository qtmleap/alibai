# AlibAI シナリオ・スキーマ改修パッケージ

対象: `qtmleap/alibai`、参照コミット `849cb8b01ef954f3722968acad4e3478baec349f`（develop）。

**リポジトリには未反映です。** Local MCP が利用できず、GitHub のブランチ作成も
`403 Resource not accessible by integration` で拒否されたため、適用用にまとめています。
このパッケージはDB・シードSQL・本番環境・Gitブランチを変更しません。

## 変更内容

保存形式は `schemaVersion: 1` のままです。共通化するのは参照、前提条件、所見の基本構造、
判定条件のテキスト制約です。証拠とRevelationの意味や、公開情報と秘匿情報の区別は残します。

- `alibai/db/scenario-fields.ts`: ID・時刻・判定条件・source参照・前提条件・所見の基本構造を共通化。
- `alibai/db/scenario-floor-plan.ts`: 既存の図面スキーマを再利用し、作者入力だけを入れ子まで厳格化。
- `alibai/db/scenario-definition.ts`: 共通定義の利用、未知キーの拒否、生成用JSON Schemaへの参照説明の追加。
- `alibai/db/victim-finding.ts`: 所見の共通定義を利用。実行時には省略のない前提条件を要求。
- `alibai/db/scenarios/tsukimisou.yaml`: 取得元、証明できる事実、所見と解禁条件の対応、時系列の参照を修正。
- `alibai/__tests__/db/scenario-schema-contract.test.ts`: 17件の契約・互換性テストを追加。
- `alibai/__tests__/db/tsukimisou-discovery.test.ts`: 8件のシナリオ回帰テストを追加。

「十七回忌の客」は、携帯履歴と電話ボックスの混同、架空の目撃、未実施の分析結果の開示、
園の記録から持ち出した人物まで断定する紐付けを整理しています。指定の控え → 見直し草案 →
本人が認めた焦り、という順に確認できるようにし、調べられない部屋への証拠sourceも除いています。

## 適用

Python 3.10以上の標準ライブラリだけで動きます。追加パッケージのインストールは不要です。
展開したフォルダと、実際の `alibai` リポジトリを別の場所に置いて実行してください。

```sh
# 読み取り確認のみ。ファイルは変更しない。
python3 alibai-scenario-refactor/apply.py --repo ./alibai

# 確認が成功したときだけ、対象7ファイルを変更・追加する。
python3 alibai-scenario-refactor/apply.py --repo ./alibai --apply
```

先に通常のパッチを見たい場合は、`--apply` の代わりに次を使います。

```sh
python3 alibai-scenario-refactor/apply.py --repo ./alibai --patch ./alibai-schema-refactor.patch
```

変更対象3ファイルのGit blob SHAをすべて照合し、新規4ファイルが既に存在する場合も停止します。
参照コミット以降に対象ファイルを編集していた場合、強制上書きせず、既存変更との調整が必要です。
適用前の照合に失敗した場合はリポジトリへ書き込みません。

## 検証状況と実行コマンド

**追加したBunテスト25件、既存テスト全体、プロジェクトの型チェックは未実行です。**
作業環境にBunとプロジェクト依存パッケージがなく、書き込み権限もないためCIへ渡せていません。
TypeScriptの構文解析と適用スクリプト自身のテストは別途 `verification.txt` に記載しています。
それらはZodの動作確認やプロジェクトの型チェックの代わりではありません。

適用後はリポジトリで次を実行してください。

```sh
cd alibai
bun test __tests__/db/scenario-schema-contract.test.ts __tests__/db/tsukimisou-discovery.test.ts
bun test
bun run typecheck
bun run lint
git diff --check
```

## 今回含めていないもの

証拠IDのサーバーでの常時照合、証拠とRevelationの実行時取得エンジン統合、混在依存グラフの
到達可能性検査、knowledgeとsecretsの重複拒否、Judgeの根拠付き出力・最終採点基準の変更は
このパッケージには含めていません。生成用の説明を追加した項目でも、説明だけで意味の
正しさが保証されるわけではありません。実モデルでの判定精度・解決可能性の評価も未実施です。
